import 'package:flutter/material.dart';
import 'package:paginador_pisos/screens/home_page.dart';

void main() {
  runApp(const PaginadorApp());
}

class PaginadorApp extends StatelessWidget {
  const PaginadorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Paginador de Pisos',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueGrey),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}